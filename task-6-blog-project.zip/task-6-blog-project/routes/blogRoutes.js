const express = require("express")
const blogRouter = express.Router()
const Blog = require("../model/blogModel")
const User = require("../model/authModel")
const path = require("path")
const fs = require("fs")
const { addBlogPage, addBlog, singleBlog, profilePage, deleteBlog, editBlog, changePasswordPage, changePassword } = require("../controller/blogController")

blogRouter.get("/addBlogPage", addBlogPage)
blogRouter.post("/addBlog", Blog.uploadImage, addBlog)
blogRouter.get("/singleBlog/:id", singleBlog)
blogRouter.get("/profilePage", profilePage)
blogRouter.get("/deleteBlog/:id", deleteBlog)
blogRouter.get("/editBlogPage/:id", editBlog)
blogRouter.post("/editBlog/:id", Blog.uploadImage, async (req, res) => {
    // try {
    //     console.log(req.body);
    //     console.log(req.file);
    //     return res.redirect(`/admin/editBlogPage/${req.params.id}`)
    // } catch (error) {
    //     console.log(error);
    // }

    try {
        let record = await Blog.findById(req.params.id);
        console.log(record);

        if (record) {
            if (req.file) {
                let imagePath = record.coverImage;
                if (imagePath != "") {
                    imagePath = path.join(__dirname, "..", imagePath);
                    try {
                        await fs.unlinkSync(imagePath);
                    } catch (error) {
                        console.log("File Missing....");
                    }
                }
                let newImagepath = `/uploads/blogs/${req.file.filename}`;
                req.body.coverImage = newImagepath
            } else {
                req.body.coverImage = record.coverImage
            }
            await Blog.findByIdAndUpdate(req.params.id, req.body, { new: true });
            console.log("Blog Updated...");
            return res.redirect("/home")
        } else {
            console.log("Record not Found...")
            return res.redirect('back');
        }
    } catch (error) {
        console.log(error);
        return res.redirect('back');
    }
})
blogRouter.get("/changePasswordPage", changePasswordPage)
blogRouter.post("/changePassword", changePassword)
module.exports = blogRouter