const Blog = require("../model/blogModel")
const User = require("../model/authModel")

exports.addBlogPage=(req, res) => {
    try {
        if (req.cookies.loginUser == undefined || req.cookies.loginUser._id == undefined) {
            return res.redirect("/signInPage")
        }
        else {
            return res.render("addBlog")
        }
    } catch (error) {
        console.log(error);
        res.redirect("/admin/addBlogPage")
    }
}
exports.addBlog=async (req, res) => {
    try {
        // console.log(req.body);
        // console.log(req.file);
        let imagePath = ""
        if (req.file) {
            imagePath = `/uploads/blogs/${req.file.filename}`
        }
        let fullName = req.cookies.loginUser.firstName + " " + req.cookies.loginUser.lastName
        req.body.author = fullName
        req.body.authorEmail = req.cookies.loginUser.email
        req.body.coverImage = imagePath

        // console.log(req.body);
        let addedBlog = await Blog.create(req.body)
        if (addedBlog) {
            console.log("Blog Added Sucessfully...");
            return res.redirect("/home")
        }
        else {
            console.log("Blog Didnt Added");
            return res.redirect("/admin/addBlogPage")
        }

    } catch (error) {
        console.log(error);
        return res.redirect("/admin/addBlogPage")
    }
}
exports.singleBlog=async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        // console.log(blog);
        return res.render("singleBlog", { blog })
    } catch (error) {
        console.log(error);
    }
}
exports.profilePage=async (req, res) => {
    try {
        if (req.cookies.loginUser == undefined || req.cookies.loginUser._id == undefined) {
            console.log("You are not logged in");
            return res.redirect("/signInPage")
        }
        else {
            const user = req.cookies.loginUser
            const loginUserEmail = req.cookies.loginUser.email
            // console.log(user);
            const loginAdminPost = await Blog.find({ authorEmail: loginUserEmail })
            // console.log(loginAdminPost);
            return res.render("profile", { user, loginAdminPost })
        }
    } catch (error) {
        console.log(error);
    }
}
exports.deleteBlog=async (req, res) => {
    try {
        let post = await Blog.findById(req.params.id)
        if (post) {
            try {
                let imagepath = path.join(__dirname, "..", post.coverImage)
                fs.unlinkSync(imagepath);
                await Blog.findByIdAndDelete(req.params.id)
                console.log("Blog Deleted Success...");
                return res.redirect("/home")
            } catch (error) {
                console.log(error);
            }
        }
        else {
            console.log("Something Went wrong");
            return res.redirect("/admin/profilePage")
        }
    } catch (error) {
        console.log(error);
    }
}
exports.editBlog=async (req, res) => {
    try {
        let blog = await Blog.findById(req.params.id)
        return res.render("editBlog", { blog })
    } catch (error) {
        console.log(error);
    }
}
exports.changePasswordPage=(req, res) => {
    try {
        if (req.cookies.loginUser == undefined || req.cookies.loginUser._id == undefined) {
            return res.redirect("/signInPage")
        }
        else {
            return res.render("changePassword")
        }
    } catch (error) {
        console.log(error);
        return res.redirect("/back")
    }
}
exports.changePassword=async (req, res) => {
    try {
        if (req.cookies.loginUser == undefined || req.cookies.loginUser._id == undefined) {
            return res.redirect("/signInPage")
        }
        else {
            // console.log(req.body);
            let loginAdminPass = req.cookies.loginUser
            // console.log(loginAdminPass);
            if (loginAdminPass.password == req.body.oldPassword && req.body.newPassword == req.body.confirmPassword && loginAdminPass.password != req.body.newPassword) {
                const user = await User.findById(loginAdminPass._id)
                // console.log(user);
                user.password = req.body.newPassword
                await user.save()
                console.log("Changed password");
                res.clearCookie("loginUser");
                return res.redirect("/signInPage")
            }
            else {
                console.log("password didnt changed");
                return res.redirect("/admin/changePasswordPage")
            }
        }
    } catch (error) {
        console.log(error);
        return res.redirect("/admin/changePasswordPage")
    }
}